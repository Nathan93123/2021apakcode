class Cake:
    def __init__(self, weight, value):
        self.weight = weight
        self.value = value
        self.per_weight_value = value / weight

    def __str__(self):
        return f'{{weight: {self.weight}, value: {self.value}, ratio: {self.per_weight_value}}}'

    def __repr__(self):
        return f'{{weight: {self.weight}, value: {self.value}, ratio: {self.per_weight_value}}}'


def get_max_score(cakes, capacity):
    score = 0
    for c in sorted(cakes, key=lambda cake: cake.per_weight_value, reverse=True):
        if capacity <= 0:
            break

        if capacity >= c.weight:
            load = capacity // c.weight
            score += c.value * load
            capacity -= c.weight * load
    return score


if __name__ == "__main__":
    capacity = 20
    print("Nice job: " + str(get_max_score([Cake(7, 160), Cake(3, 90), Cake(2, 15)], 20)))
