# UserProfile_Service


The following configuartion is required to run the web application:
{
  "IPstackApiKey": "provide_key",
  "UserData": {
    "FilePath": "provide_path",
    "Filename": "provide_name"
  }
}
