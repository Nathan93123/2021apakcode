﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Refit;

namespace UserProfile_Service.Clients
{
    public interface IUserGeolocationClient
    {
        [Get("/{ipAddress}?access_key={access_key}")]
        Task<ApiResponse<UserGeolocation>> GetUserGeolocation(string ipAddress, string access_key);
    }

    public class UserGeolocation
    {
        public string City { get; set; }
    }
}
