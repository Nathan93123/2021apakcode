﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mime;
using System.Threading.Tasks;
using UserProfile_Service.Models;
using Wangkanai.Detection.Services;
using UserProfile_Service.Clients;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Hosting;
using System.IO;
using CsvHelper;
using System.Globalization;
using CsvHelper.Configuration;
using Microsoft.AspNetCore.Http;

namespace UserProfile_Service.Controllers
{
    [Produces(MediaTypeNames.Application.Json)]
    [Route("api/[controller]")]
    [ApiController]
    public class UserProfileController : ControllerBase
    {
        private readonly ILogger<UserProfileController> _logger;
        private readonly IDetectionService _detectionService;
        private readonly IUserGeolocationClient _client;
        private readonly IConfiguration _config;
        private readonly UserDataOptions _options;
        private readonly IWebHostEnvironment _env;
        private readonly String _userDataFile;
        private CsvConfiguration _csvconfig = new CsvConfiguration(CultureInfo.InvariantCulture)
        {
            NewLine = Environment.NewLine,
        };
       
        public UserProfileController(ILogger<UserProfileController> logger, IDetectionService detectionService, 
            IUserGeolocationClient client, IConfiguration config, IWebHostEnvironment env, IOptions<UserDataOptions> options)
        {
            _detectionService = detectionService;
            _logger = logger;
            _client = client;
            _config = config;
            _options = options.Value;
            _env = env;
            _userDataFile = System.IO.Path.Combine(_options.FilePath, _options.FileName);
        }

        // GET: api/<UserProfileController>
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult<UserProfileDTO>> GetAsync()
        {
            UserProfileDTO userProfile = new()
            {
                Device = _detectionService.Device.Type.ToString(),
            };
            (userProfile.Date, userProfile.Time ) = Helper.RecordDateTime();

            userProfile.IPAddress = Helper.FindIP(Request.HttpContext.Connection.RemoteIpAddress, _env.EnvironmentName);
            var response = await _client.GetUserGeolocation(userProfile.IPAddress, _config["IPstackApiKey"]);
            await response.EnsureSuccessStatusCodeAsync();

            // TODO: Retrieve complete time zone and location from IPStack
            userProfile.Location = response.Content.City ?? "Unknown";

            return Ok(userProfile);
        }

        // POST api/<UserProfileController>
        [HttpPost]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult<UserProfile>> CreateAsync(UserProfile userProfile)
        {
            userProfile.Device = _detectionService.Device.Type.ToString();
            (userProfile.Date, userProfile.Time) = Helper.RecordDateTime();

            userProfile.IPAddress = Helper.FindIP(Request.HttpContext.Connection.RemoteIpAddress, _env.EnvironmentName);
            var response = await _client.GetUserGeolocation(userProfile.IPAddress, _config["IPstackApiKey"]);
            await response.EnsureSuccessStatusCodeAsync();

            userProfile.Location = response.Content.City ?? "Unknown";

            System.IO.Directory.CreateDirectory(_options.FilePath);
            if (!System.IO.File.Exists(_userDataFile))
            {
                System.IO.File.Create(_userDataFile).Close();
                _csvconfig.HasHeaderRecord = false;
            }
              
            using (var writer = new StreamWriter(_userDataFile, append : true))
            using (var csv = new CsvWriter(writer, _csvconfig))
            {
                csv.Context.RegisterClassMap<UserProfileMap>();
                if (!_csvconfig.HasHeaderRecord)
                {
                    csv.WriteHeader<UserProfile>();
                    await csv.NextRecordAsync();
                }
                Helper.SaveUser(csv, userProfile);
                await csv.NextRecordAsync();
            }
            return Ok();
        }

        // DELETE api/<UserProfileController>/5
        [HttpDelete("{username}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> DeleteAsync(string username)
        {  
            if (!System.IO.File.Exists(_userDataFile))
                return NotFound();
            bool userExists = false;

            var tmpCsvFile = _userDataFile + ".tmp";
            using (var writer = new StreamWriter(tmpCsvFile))
            using (var tmpCsv = new CsvWriter(writer, _csvconfig))
            {
                tmpCsv.Context.RegisterClassMap<UserProfileMap>();
                tmpCsv.WriteHeader<UserProfile>();
                await tmpCsv.NextRecordAsync();
                bool VerifyUser(ShouldSkipRecordArgs x)
                {
                    if (x.Record[5] == username)
                    {
                        userExists = true;
                        return true;
                    }
                    return false;
                }
                var config = new CsvConfiguration(CultureInfo.InvariantCulture)
                {
                    HasHeaderRecord = true,
                    ShouldSkipRecord = VerifyUser
                };
                using var reader = new StreamReader(_userDataFile);
                using var csvRead = new CsvReader(reader, config);
                csvRead.Context.RegisterClassMap<UserProfileMap>();
                var src = csvRead.GetRecordsAsync<UserProfile>();
                await foreach (UserProfile record in src)
                {
                    Helper.SaveUser(tmpCsv, record);
                    await tmpCsv.NextRecordAsync();
                }
            }
            if (!userExists)
                return NotFound();
           
            System.IO.File.Copy(tmpCsvFile, _userDataFile, true);
           
            return Ok();
        }
    }
}
