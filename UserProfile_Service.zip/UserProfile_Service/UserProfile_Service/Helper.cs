﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserProfile_Service
{
    public class Helper
    {
        public static string FindIP(System.Net.IPAddress address, string env)
        {
            if (env == "Development")
            {
                if (address != null)
                {
                    if (address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetworkV6)
                    {
                        address = System.Net.Dns.GetHostEntry(address)
                            .AddressList
                            .First(x => x.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork);
                    }
                }
            }
            return address.ToString();
        }

        public static (string, string) RecordDateTime()
        {
            DateTime utcDate = DateTime.UtcNow;
            return (utcDate.ToString("d"), utcDate.ToString("T"));
        }

        public static void SaveUser(CsvHelper.CsvWriter csv, Models.UserProfile userProfile)
        {
            csv.WriteField(userProfile.Date);
            csv.WriteField(userProfile.Time);
            csv.WriteField(userProfile.Location);
            csv.WriteField(userProfile.Device);
            csv.WriteField(userProfile.IPAddress);
            csv.WriteField(userProfile.Username);
            csv.WriteField(userProfile.Name);
            csv.WriteField(String.Join(",", userProfile.Interests));
        }
    }
}
