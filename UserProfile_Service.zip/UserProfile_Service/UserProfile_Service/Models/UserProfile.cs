﻿using CsvHelper.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserProfile_Service.Models
{
    public class UserProfileMap : ClassMap<UserProfile>
    {
        public UserProfileMap()
        {
            Map(m => m.Date).Index(0).Name("date");
            Map(m => m.Time).Index(1).Name("time");
            Map(m => m.Location).Index(2).Name("location");
            Map(m => m.Device).Index(3).Name("device");
            Map(m => m.IPAddress).Index(4).Name("ipaddress");
            Map(m => m.Username).Index(5).Name("username");
            Map(m => m.Name).Index(6).Name("name");
            Map(m => m.Interests).Index(7).Name("interests");
        }
    }

    public class UserProfile
    {
        public string IPAddress { get; set; }
        public string Device { get; set; }
        public string Location { get; set; }
        public string Date { get; set; }
        public string Time { get; set; }
        public string Name { get; set; }
        public string Username { get; set; }
        public List<String> Interests { get; set; }
    }
}
