﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserProfile_Service.Models
{
    public class UserProfileDTO
    {
        public string IPAddress { get; set; }
        public string Device { get; set; }
        public string Date { get; set; }
        public string Time { get; set; }
        public string Location { get; set; }
    }
}
